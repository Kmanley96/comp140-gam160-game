﻿using UnityEngine;
using System.Collections;

public class JumpPads : MonoBehaviour
{
public float bounceForce = 400f;

	void OnCollisionEnter2D (Collision2D hit)
	{
		if (hit.gameObject.tag == "Player")
		{
			hit.rigidbody.AddForce (bounceForce * transform.up, ForceMode2D.Force);
		}
	}
}

