﻿using UnityEngine;
using System.Collections;

public class rotatingCircle : MonoBehaviour
{
	// Update is called once per frame

	void Update()
	{
		if (Input.GetKey ("left")) 
		{
			transform.Rotate (0, 0,1);
		}

			if(Input.GetKey("right"))
			{
			transform.Rotate (0, 0, -1);
			}
	}
}