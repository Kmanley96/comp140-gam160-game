﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
public class EndOfTheGame : MonoBehaviour
{
	//when the player hits the collider the player will go back to the main menu
	void OnTriggerEnter2D(Collider2D col)
	{
		if (col.CompareTag("Player"))
		{
			SceneManager.LoadScene (SceneManager.GetActiveScene ().buildIndex -3);
		}
	}

}
