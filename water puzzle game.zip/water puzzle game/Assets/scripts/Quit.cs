﻿using UnityEngine;
using System.Collections;

public class Quit : MonoBehaviour 
{
	//when the player hits the collider the player will go back to the
public void quit ()

	#if UNITY_EDITOR
	{
		UnityEditor.EditorApplication.isPlaying = false;
	#else
	Application.quit ();

	#endif
	}
}